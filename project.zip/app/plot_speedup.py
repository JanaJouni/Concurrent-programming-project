import pandas as pd
import matplotlib.pyplot as plt

file_path = "final_results.csv"

# --- SPEEDUP PLOTTING ---

with open(file_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

# Parse Speedup Comparison section
speedup_lines = lines[47:]  # from line 47
speedup_data = []
for line in speedup_lines:
    line = line.strip()
    if not line or "Average" in line or "===" in line:
        continue
    parts = line.split(',')
    if len(parts) >= 2:
        try:
            threads = int(parts[0])
            speedup = float(parts[1])
            speedup_data.append((threads, speedup))
        except ValueError:
            continue

df_speedup = pd.DataFrame(speedup_data, columns=["Threads", "Speedup"])

plt.figure(figsize=(10, 6))
plt.plot(df_speedup["Threads"], df_speedup["Speedup"], marker='o', label="Measured Speedup")
plt.plot(df_speedup["Threads"], df_speedup["Threads"], linestyle='--', color='gray', label="Ideal Speedup")
plt.title("Speedup vs Threads")
plt.xlabel("Threads")
plt.ylabel("Speedup")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig("speedup_chart.png")
plt.show()


# --- PARALLEL TIME PLOTTING ---

# Find Parallel Results section
parallel_start = None
for i, line in enumerate(lines):
    if "=== Parallel Results" in line:
        parallel_start = i
        break

parallel_data = []
if parallel_start is not None:
    parallel_lines = lines[parallel_start + 2:]  # skip header + column line
    for line in parallel_lines:
        line = line.strip()
        if not line or "===" in line:
            break
        parts = line.split(',')
        if len(parts) == 1:
            parts = line.split()
        if len(parts) >= 2:
            try:
                threads = int(parts[0])
                avg_time = float(parts[1])
                parallel_data.append((threads, avg_time))
            except ValueError:
                continue

df_parallel = pd.DataFrame(parallel_data, columns=["Threads", "Avg_Time"])

# Calculate average sequential time
sequential_times = []
seq_start = None
for i, line in enumerate(lines):
    if "=== Sequential Results" in line:
        seq_start = i
        break

if seq_start is not None:
    for line in lines[seq_start + 2:]:
        line = line.strip()
        if not line or "===" in line:
            break
        parts = line.split(',')
        if len(parts) == 1:
            parts = line.split()
        if len(parts) >= 2:
            try:
                t = float(parts[1])
                sequential_times.append(t)
            except ValueError:
                continue

avg_seq_time = sum(sequential_times) / len(sequential_times) if sequential_times else None

plt.figure(figsize=(10, 6))
plt.plot(df_parallel["Threads"], df_parallel["Avg_Time"], marker='o', label="Parallel Avg Time")

if avg_seq_time is not None:
    plt.axhline(y=avg_seq_time, color='red', linestyle='--', label=f"Sequential Avg Time = {avg_seq_time:.2f} s")

plt.title("Average Execution Time vs Threads")
plt.xlabel("Threads")
plt.ylabel("Avg Time (s)")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig("avg_time_vs_threads.png")
plt.show()

